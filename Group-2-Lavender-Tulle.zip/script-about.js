// /* .js files add interaction to your website */
// Javascript for button added by Sukanya. Please don't change anything
// var factList = [
//   "In South Asia, the Hijra community has a long history of gender variance and is considered one of the oldest recorded transgender communities in the world. Hijras are neither male nor female but are a third gender. They have been a part of Indian society for thousands of years and have even been mentioned in ancient Hindu texts like the Kama Sutra.",
//   "In 2014, Taiwan’s LGBT community played a significant role in the Sunflower Movement, a student-led protest against a proposed trade agreement with China. The movement was successful in blocking the agreement and helped to bring attention to LGBT rights in Taiwan.",
//   "Hau Dong is a religious ceremony practiced in Vietnam that involves spirit mediums who are often gay or transgender. During the ceremony, the mediums communicate with the spirit world and are believed to have special powers that can heal the sick and bring good luck.",
//   "Waria is a term used in Indonesia to describe transgender women who are accepted as a third gender. They are an important part of Indonesian culture and are often seen as performers and entertainers. One of the most famous waria is Dorce Gamalama, a TV personality who has become a household name in Indonesia.."];
  
// // var fact = document.getElementById("fact");
// var fact = $('.fact');
// // var myButton = document.getElementById("myButton");
// var myButton = $('.myButton')
// var count = 0;

// // myButton.addEventListener("click", displayFact);
// myButton.on("click", displayFact)

// function displayFact () {
//   // fact.css("background-color", "lavender");  
//   fact.text(factList[count]);
//   fact.css("display", "block");
  
//  // fact.innerHTML = factList[count];
//   count++;
//   if (count == factList.length) {
//     count = 0;
//   }
  
// }
// //end of about button


